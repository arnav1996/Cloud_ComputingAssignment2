## Restaurant Recommendation Bot

A restaurant recommendation bot, that will email you restaurant suggestions given a set of preferences that you give the chatbot through conversation.

## Architecture 
![alt text](https://github.com/darshildpatel/Virtual-Dining-Concierge-Assistant/blob/master/architecture.png)



## <a name = "team-members"></a>Team Members
* "Ayush Sethi"<as11500@nyu.edu>
* "Darshil Patel"<ddp337@nyu.edu>


##  
  Made with :heart: in New York :statue_of_liberty:
